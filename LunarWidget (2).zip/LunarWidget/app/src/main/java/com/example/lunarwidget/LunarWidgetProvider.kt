package com.example.lunarwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.provider.AlarmClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.min

class LunarWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    // Gọi lại khi người dùng kéo giãn / đổi cỡ widget
    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        update(context, manager, id, newOptions)
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        super.onDeleted(context, ids)
        WidgetPrefs.clear(context, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, LunarWidgetProvider::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    companion object {

        fun update(
            context: Context,
            manager: AppWidgetManager,
            id: Int,
            options: Bundle = manager.getAppWidgetOptions(id)
        ) {
            manager.updateAppWidget(id, buildViews(context, id, options))
        }

        private class Spec(val layout: Int, val bold: IntArray, val light: IntArray)

        private fun specFor(layoutStyle: Int): Spec = when (layoutStyle) {
            1 -> Spec(R.layout.widget_left, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
            2 -> Spec(R.layout.widget_side, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
            3 -> Spec(
                R.layout.widget_stack,
                intArrayOf(R.id.clock_h_bold, R.id.clock_m_bold),
                intArrayOf(R.id.clock_h_light, R.id.clock_m_light)
            )
            4 -> Spec(
                R.layout.widget_glassclock,
                intArrayOf(R.id.clock_glass_a, R.id.clock_glass_b),
                intArrayOf()
            )
            else -> Spec(R.layout.widget_main, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
        }

        private fun buildViews(context: Context, id: Int, options: Bundle): RemoteViews {
            val style = WidgetPrefs.load(context, id)
            val spec = specFor(style.layout)
            val views = RemoteViews(context.packageName, spec.layout)
            val now = Calendar.getInstance()

            // ---- Nội dung (luôn hiển thị đủ giờ, ngày dương, âm lịch) ----
            val dateText = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi", "VN")).format(Date())
            views.setTextViewText(R.id.date, dateText.replaceFirstChar { it.uppercase() })

            val lunar = LunarCalendar.solarToLunar(
                now.get(Calendar.DAY_OF_MONTH),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.YEAR)
            )
            val leap = if (lunar.leap) " nhuận" else ""
            views.setTextViewText(
                R.id.lunar,
                "Âm lịch: ${lunar.day}/${lunar.month}$leap · ${LunarCalendar.yearName(lunar.year)}"
            )

            // ---- Màu chữ & kiểu chữ ----
            val main = if (style.dark) Color.BLACK else Color.WHITE
            val sub = if (style.dark) Color.argb(0xE6, 0, 0, 0) else Color.argb(0xF2, 255, 255, 255)
            views.setTextColor(R.id.date, main)
            views.setTextColor(R.id.lunar, sub)
            val showLight = style.light && spec.light.isNotEmpty()
            spec.bold.forEach {
                views.setTextColor(it, main)
                views.setViewVisibility(it, if (showLight) View.GONE else View.VISIBLE)
            }
            spec.light.forEach {
                views.setTextColor(it, main)
                views.setViewVisibility(it, if (showLight) View.VISIBLE else View.GONE)
            }
            if (style.layout == 4) {
                // Kính mờ: chữ giờ trong suốt, hai lớp chồng nhau
                val base = if (style.dark) 0 else 255
                views.setTextColor(R.id.clock_glass_a, Color.argb(0x4D, base, base, base))
                views.setTextColor(R.id.clock_glass_b, Color.argb(0x40, base, base, base))
            }

            // ---- Kích cỡ: chữ tự co giãn theo khung widget ----
            val portrait = context.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
            var wDp = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH
                else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0
            )
            var hDp = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT
                else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0
            )
            if (wDp <= 0) wDp = 320
            if (hDp <= 0) hDp = 150

            val textSp: Float
            val clockSp: Float
            when (style.layout) {
                2 -> {
                    textSp = min((wDp / 32f).coerceIn(8f, 18f), (hDp - 8) / 2.9f)
                    clockSp = min((wDp - 28 - 12 * textSp) / 2.75f, (hDp - 8) / 1.15f)
                }
                3 -> {
                    textSp = min((wDp / 30f).coerceIn(8f, 20f), (hDp - 8) / 2.9f)
                    clockSp = min((wDp - 28 - 12 * textSp) / 1.3f, (hDp - 8) / 2.35f)
                }
                4 -> {
                    textSp = min((wDp / 22f).coerceIn(8f, 26f), hDp / 9f)
                    clockSp = min((wDp - 16) / 2.85f, (hDp - 8 - 2 * textSp * 1.4f) / 1.15f)
                }
                else -> {
                    textSp = min((wDp / 22f).coerceIn(8f, 26f), hDp / 9f)
                    clockSp = min((wDp - 16) / 2.75f, (hDp - 8 - 2 * textSp * 1.4f) / 1.15f)
                }
            }
            val clockFinal = clockSp.coerceIn(14f, 220f)
            val textFinal = textSp.coerceAtLeast(7f)

            (spec.bold + spec.light).forEach {
                views.setTextViewTextSize(it, TypedValue.COMPLEX_UNIT_SP, clockFinal)
            }
            views.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, textFinal)
            views.setTextViewTextSize(R.id.lunar, TypedValue.COMPLEX_UNIT_SP, textFinal * 0.9f)

            // ---- Chạm: giờ -> app Đồng hồ; ngày / âm lịch -> app Lịch ----
            val fallback = Intent(context, MainActivity::class.java)
            val clockPi = pendingFor(context, Intent(AlarmClock.ACTION_SHOW_ALARMS), fallback, 1)
            val calendarPi = pendingFor(
                context,
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
                fallback, 2
            )
            (spec.bold + spec.light).forEach { views.setOnClickPendingIntent(it, clockPi) }
            views.setOnClickPendingIntent(R.id.date, calendarPi)
            views.setOnClickPendingIntent(R.id.lunar, calendarPi)
            views.setOnClickPendingIntent(R.id.widget_root, calendarPi)
            return views
        }

        private fun pendingFor(context: Context, intent: Intent, fallback: Intent, code: Int): PendingIntent {
            val target = if (intent.resolveActivity(context.packageManager) != null) intent else fallback
            target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(
                context, code, target, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }
}
