package com.example.lunarwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class LunarWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, buildViews(context, manager.getAppWidgetOptions(it))) }
    }

    // Gọi lại khi người dùng kéo giãn/đổi cỡ widget
    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        manager.updateAppWidget(id, buildViews(context, newOptions))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, LunarWidgetProvider::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    private fun buildViews(context: Context, options: Bundle): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_glass)
        val now = Calendar.getInstance()

        val dateText = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi", "VN")).format(Date())
        views.setTextViewText(R.id.date, dateText.replaceFirstChar { it.uppercase() })

        val lunar = LunarCalendar.solarToLunar(
            now.get(Calendar.DAY_OF_MONTH),
            now.get(Calendar.MONTH) + 1,
            now.get(Calendar.YEAR)
        )
        val leap = if (lunar.leap) " nhuận" else ""
        views.setTextViewText(
            R.id.lunar,
            "Âm lịch: ${lunar.day}/${lunar.month}$leap · ${LunarCalendar.yearName(lunar.year)}"
        )

        // Giữ tỉ lệ thẻ kính cố định (rộng : cao = 1.9) trên mọi điện thoại:
        // phần khung widget thừa được chừa trong suốt, thẻ kính nằm giữa.
        val portrait = context.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
        val wDp = options.getInt(
            if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH
            else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0
        )
        val hDp = options.getInt(
            if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT
            else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0
        )
        if (wDp > 0 && hDp > 0) {
            val ratio = 1.9f
            var cardW = wDp.toFloat()
            var cardH = cardW / ratio
            if (cardH > hDp) {
                cardH = hDp.toFloat()
                cardW = cardH * ratio
            }
            val density = context.resources.displayMetrics.density
            val padX = ((wDp - cardW) / 2f * density).toInt().coerceAtLeast(0)
            val padY = ((hDp - cardH) / 2f * density).toInt().coerceAtLeast(0)
            views.setViewPadding(R.id.widget_outer, padX, padY, padX, padY)
        }

        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, open)
        return views
    }
}
