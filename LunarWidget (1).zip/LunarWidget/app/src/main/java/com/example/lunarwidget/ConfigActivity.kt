package com.example.lunarwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

/** Màn hình tùy chỉnh: hiện khi thêm widget, và khi nhấn giữ widget → Cài đặt. */
class ConfigActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        val widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val cur = WidgetPrefs.load(this, widgetId)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun heading(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun radios(options: List<String>, selected: Int): Pair<RadioGroup, List<RadioButton>> {
            val buttons = options.map { label ->
                RadioButton(this).apply { text = label; id = View.generateViewId() }
            }
            val group = RadioGroup(this).apply {
                buttons.forEach { addView(it) }
                check(buttons[selected].id)
            }
            return group to buttons
        }

        root.addView(heading("Tùy chỉnh widget", 22f))
        root.addView(TextView(this).apply {
            text = "Kiểu nào cũng hiển thị đủ giờ, ngày dương lịch và âm lịch."
            textSize = 13f
        })

        root.addView(heading("Kiểu bố cục"))
        val (layoutGroup, layoutBtns) = radios(
            listOf(
                "Căn giữa (mặc định)",
                "Căn trái",
                "Giờ bên trái, ngày bên phải",
                "Giờ xếp dọc (14 trên 40), ngày bên phải"
            ),
            cur.layout.coerceIn(0, 3)
        )
        root.addView(layoutGroup)

        root.addView(heading("Màu chữ"))
        val (colorGroup, colorBtns) = radios(listOf("Trắng", "Đen"), if (cur.dark) 1 else 0)
        root.addView(colorGroup)

        root.addView(heading("Kiểu chữ giờ"))
        val (weightGroup, weightBtns) = radios(listOf("Đậm", "Mỏng"), if (cur.light) 1 else 0)
        root.addView(weightGroup)

        root.addView(TextView(this).apply {
            text = "Đổi kích cỡ: nhấn giữ widget trên màn hình chính rồi kéo các chấm ở viền."
            textSize = 13f
            setPadding(0, pad, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "Lưu"
            setOnClickListener {
                WidgetPrefs.save(
                    this@ConfigActivity, widgetId,
                    WidgetPrefs.Style(
                        layout = layoutBtns.indexOfFirst { it.isChecked }.coerceAtLeast(0),
                        dark = colorBtns[1].isChecked,
                        light = weightBtns[1].isChecked
                    )
                )
                LunarWidgetProvider.update(
                    this@ConfigActivity, AppWidgetManager.getInstance(this@ConfigActivity), widgetId
                )
                setResult(
                    RESULT_OK,
                    Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                )
                finish()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
