package com.example.lunarwidget

import android.content.Context

/** Lưu kiểu dáng riêng cho từng widget. */
object WidgetPrefs {
    data class Style(
        val layout: Int = 0,        // 0 giữa, 1 căn trái, 2 giờ trái - ngày phải, 3 giờ xếp dọc
        val dark: Boolean = false,  // chữ đen thay vì trắng
        val light: Boolean = false  // giờ kiểu mỏng thay vì đậm
    )

    private const val FILE = "widget_prefs"

    fun load(context: Context, id: Int): Style {
        val p = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return Style(
            layout = p.getInt("layout_$id", 0),
            dark = p.getBoolean("dark_$id", false),
            light = p.getBoolean("light_$id", false)
        )
    }

    fun save(context: Context, id: Int, s: Style) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt("layout_$id", s.layout)
            .putBoolean("dark_$id", s.dark)
            .putBoolean("light_$id", s.light)
            .apply()
    }

    fun clear(context: Context, ids: IntArray) {
        val e = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
        ids.forEach { id -> e.remove("layout_$id").remove("dark_$id").remove("light_$id") }
        e.apply()
    }
}
