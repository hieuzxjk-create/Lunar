# Không cần luật riêng: widget, activity khai báo trong Manifest được giữ tự động.
