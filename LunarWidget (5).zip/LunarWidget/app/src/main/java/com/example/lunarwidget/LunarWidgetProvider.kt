package com.example.lunarwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class LunarWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    // Gọi lại khi người dùng kéo giãn / đổi cỡ widget
    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        update(context, manager, id, newOptions)
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        super.onDeleted(context, ids)
        WidgetPrefs.clear(context, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, LunarWidgetProvider::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    companion object {

        fun update(
            context: Context,
            manager: AppWidgetManager,
            id: Int,
            options: Bundle = manager.getAppWidgetOptions(id)
        ) {
            manager.updateAppWidget(id, buildViews(context, id, options))
        }

        private class Spec(val layout: Int, val bold: IntArray, val light: IntArray)

        private fun specFor(layoutStyle: Int): Spec = when (layoutStyle) {
            1 -> Spec(R.layout.widget_left, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
            2 -> Spec(R.layout.widget_side, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
            3 -> Spec(
                R.layout.widget_stack,
                intArrayOf(R.id.clock_h_bold, R.id.clock_m_bold),
                intArrayOf(R.id.clock_h_light, R.id.clock_m_light)
            )
            4 -> Spec(
                R.layout.widget_glassclock,
                intArrayOf(R.id.clock_glass_a, R.id.clock_glass_b),
                intArrayOf()
            )
            else -> Spec(R.layout.widget_main, intArrayOf(R.id.clock_bold), intArrayOf(R.id.clock_light))
        }

        private class Fit(val sp: Float, val slackTopPx: Float, val slackBottomPx: Float)

        /**
         * Tính cỡ giờ cho các bố cục xếp dọc (giờ, ngày, âm lịch) bằng cách ĐO font thật của máy:
         * giờ vừa khít chiều ngang và chiều cao, các dòng dưới không bao giờ bị đẩy ra ngoài.
         * Android 12+ còn cắt bỏ khoảng trống thừa trên/dưới số để ngày nằm sát giờ.
         */
        private fun fitStackedClock(
            context: Context, wDp: Int, hDp: Int, textSp: Float, fs: Float,
            tf: Typeface, letter: Float
        ): Fit {
            val d = context.resources.displayMetrics.density
            val wPx = (wDp - 16) * d
            val hPx = (hDp - 8) * d * 0.92f
            val ref = 100f

            val clockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = tf
                textSize = ref
                letterSpacing = letter
            }
            var wRef = 1f
            for (t in arrayOf("00:00", "08:08", "20:20", "11:11")) {
                wRef = max(wRef, clockPaint.measureText(t))
            }
            val fm = clockPaint.fontMetrics
            val b = Rect()
            clockPaint.getTextBounds("0123456789", 0, 10, b)
            val glyphH = (b.bottom - b.top).toFloat().coerceAtLeast(1f)
            val slackTop = (b.top - fm.ascent).coerceAtLeast(0f)
            val slackBottom = (fm.descent - b.bottom).coerceAtLeast(0f)

            val tight = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            val boxH = if (tight) glyphH else (fm.descent - fm.ascent)

            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.textSize = textSp * fs * d
            val dateH = tp.fontMetrics.let { it.bottom - it.top }
            tp.textSize = textSp * 0.9f * fs * d
            val lunarH = tp.fontMetrics.let { it.bottom - it.top }

            val avail = hPx - dateH - lunarH
            val sPx = min(wPx / wRef * ref, avail / boxH * ref).coerceAtLeast(ref * 0.2f)
            val k = sPx / ref
            return Fit(
                sPx / (fs * d),
                if (tight) slackTop * k else 0f,
                if (tight) slackBottom * k else 0f
            )
        }

        private fun buildViews(context: Context, id: Int, options: Bundle): RemoteViews {
            val style = WidgetPrefs.load(context, id)
            val spec = specFor(style.layout)
            val views = RemoteViews(context.packageName, spec.layout)
            val now = Calendar.getInstance()

            // ---- Nội dung (luôn hiển thị đủ giờ, ngày dương, âm lịch) ----
            val dateText = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi", "VN")).format(Date())
            views.setTextViewText(R.id.date, dateText.replaceFirstChar { it.uppercase() })

            val lunar = LunarCalendar.solarToLunar(
                now.get(Calendar.DAY_OF_MONTH),
                now.get(Calendar.MONTH) + 1,
                now.get(Calendar.YEAR)
            )
            val leap = if (lunar.leap) " nhuận" else ""
            views.setTextViewText(
                R.id.lunar,
                "Âm lịch: ${lunar.day}/${lunar.month}$leap · ${LunarCalendar.yearName(lunar.year)}"
            )

            // ---- Màu chữ & kiểu chữ ----
            val main = if (style.dark) Color.BLACK else Color.WHITE
            val sub = if (style.dark) Color.argb(0xE6, 0, 0, 0) else Color.argb(0xF2, 255, 255, 255)
            views.setTextColor(R.id.date, main)
            views.setTextColor(R.id.lunar, sub)
            val showLight = style.light && spec.light.isNotEmpty()
            spec.bold.forEach {
                views.setTextColor(it, main)
                views.setViewVisibility(it, if (showLight) View.GONE else View.VISIBLE)
            }
            spec.light.forEach {
                views.setTextColor(it, main)
                views.setViewVisibility(it, if (showLight) View.VISIBLE else View.GONE)
            }
            if (style.layout == 4) {
                // Kính mờ: chữ giờ trong suốt, hai lớp chồng nhau
                val base = if (style.dark) 0 else 255
                views.setTextColor(R.id.clock_glass_a, Color.argb(0x4D, base, base, base))
                views.setTextColor(R.id.clock_glass_b, Color.argb(0x40, base, base, base))
            }

            // ---- Kích cỡ: chữ tự co giãn theo khung widget ----
            val fs = max(1f, context.resources.configuration.fontScale)
            val portrait = context.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
            var wDp = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH
                else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0
            )
            var hDp = options.getInt(
                if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT
                else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0
            )
            if (wDp <= 0) wDp = 320
            if (hDp <= 0) hDp = 150

            val textSp: Float
            val clockSp: Float
            when (style.layout) {
                2 -> {
                    val t = min((wDp / 32f).coerceIn(8f, 18f), (hDp - 8) / 2.9f)
                    textSp = t / fs
                    clockSp = min((wDp - 28 - 12 * t) / 2.75f, (hDp - 8) / 1.3f) / fs
                }
                3 -> {
                    val t = min((wDp / 30f).coerceIn(8f, 20f), (hDp - 8) / 2.9f)
                    textSp = t / fs
                    clockSp = min((wDp - 28 - 12 * t) / 1.3f, (hDp - 8) / 2.6f) / fs
                }
                else -> {
                    textSp = min((wDp / 22f).coerceIn(8f, 26f), hDp / 9f) / fs
                    val tf = when {
                        style.layout == 4 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                        style.light -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                        else -> Typeface.create("sans-serif", Typeface.BOLD)
                    }
                    val letter = if (style.layout == 4) -0.04f else -0.02f
                    val fit = fitStackedClock(context, wDp, hDp, textSp, fs, tf, letter)
                    clockSp = fit.sp

                    // Android 12+: bỏ khoảng trống thừa trên/dưới số để ngày nằm sát giờ
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        (fit.slackTopPx > 0f || fit.slackBottomPx > 0f)
                    ) {
                        val boxes = if (style.layout == 4) intArrayOf(R.id.clock_glass_frame)
                        else spec.bold + spec.light
                        boxes.forEach {
                            views.setViewLayoutMargin(
                                it, RemoteViews.MARGIN_TOP, -fit.slackTopPx, TypedValue.COMPLEX_UNIT_PX
                            )
                            views.setViewLayoutMargin(
                                it, RemoteViews.MARGIN_BOTTOM, -fit.slackBottomPx, TypedValue.COMPLEX_UNIT_PX
                            )
                        }
                    }
                }
            }
            val clockFinal = clockSp.coerceIn(10f, 260f)
            val textFinal = textSp.coerceAtLeast(6f)

            (spec.bold + spec.light).forEach {
                views.setTextViewTextSize(it, TypedValue.COMPLEX_UNIT_SP, clockFinal)
            }
            views.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, textFinal)
            views.setTextViewTextSize(R.id.lunar, TypedValue.COMPLEX_UNIT_SP, textFinal * 0.9f)

            // ---- Chạm: giờ -> app Đồng hồ; ngày / âm lịch -> app Lịch ----
            val fallback = Intent(context, MainActivity::class.java)
            val clockPi = pendingFor(context, Intent(AlarmClock.ACTION_SHOW_ALARMS), fallback, 1)
            val calendarPi = pendingFor(
                context,
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
                fallback, 2
            )
            (spec.bold + spec.light).forEach { views.setOnClickPendingIntent(it, clockPi) }
            views.setOnClickPendingIntent(R.id.date, calendarPi)
            views.setOnClickPendingIntent(R.id.lunar, calendarPi)
            views.setOnClickPendingIntent(R.id.widget_root, calendarPi)
            return views
        }

        private fun pendingFor(context: Context, intent: Intent, fallback: Intent, code: Int): PendingIntent {
            val target = if (intent.resolveActivity(context.packageManager) != null) intent else fallback
            target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return PendingIntent.getActivity(
                context, code, target, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
    }
}
